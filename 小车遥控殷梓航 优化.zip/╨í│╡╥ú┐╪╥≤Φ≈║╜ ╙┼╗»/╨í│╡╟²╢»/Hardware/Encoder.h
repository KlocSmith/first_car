#ifndef __ENCODER_H
#define __ENCODER_H

void EncoderA_Init(void);
void EncoderB_Init(void);
void Timer1_Init(void);



#endif
