#ifndef __PWM_H
#define __PWM_H
#include "stdint.h"
void PWM_motor_Init(void);
void PWM_servo_Init(void);
void PWM_SetCompare_motor(uint16_t Compare);
void PWM_SetCompare_servo(uint16_t Compare);

#endif
