#ifndef __CONTRAL_H
#define __CONTRAL_H
void all_init(void);
void center_contral(void);

#endif
