#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "AD.h"
#include "Key.h"
#include "serial.h"
#include "Data_direction.h"
extern uint16_t AD_Value[2];
extern  int Button_value;
int main(void)
{

	/*模块初始化*/
	OLED_Init();		//OLED初始化
	AD_Init();					//AD初始化
	Key_Init();		//按键初始化
	Serial_Init();//串口初始化
	OLED_ShowString(1,2,"WELCOME");
	OLED_ShowString(2,10,"TO");
	OLED_ShowString(3,12,"USE");
	OLED_ShowString(4,16,"!");
	OLED_ShowString(4,1,"BUTTON1 START");
	
	while (1)
	{
		if(Key_GetNum() == 1)
		{
			OLED_Clear();
			Button_value=1;
		}
		if(Button_value == 1)
		{
				connnect();
				OLED_ShowHexNum(1,1,AD_Value[0],4);
				OLED_ShowHexNum(2,1,AD_Value[1],4);
//******************************************************************************************			
			//调整速度，初始速度默认为0
				uint8_t i = Key_GetNum(); //连续使用两个key_getnum()来读取按键状态可能会导致卡中断，
				if (i == 2)								//至于什么原因仍有待考究。
				{
					Serial_SendByte(5);//按下按键2，速度加30
				}
				else if(i == 3)
				{
					Serial_SendByte(6);//按下按键3，速度减30
				}
				Delay_ms(200);
//******************************************************************************************			
		}
		
		
	}
}
