#ifndef DATA_DIRECTION
#define DATA_DIRECTION
#include "stdint.h"
void connnect(void);
#endif
